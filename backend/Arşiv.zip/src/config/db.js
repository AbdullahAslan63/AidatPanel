import { config } from "dotenv";
config();

import { PrismaClient } from "@prisma/client";

// Development'da sadece connection status göster - güvenlik açığı düzeltildi
if (process.env.NODE_ENV === "development") {
  console.log("Database connection status: Checking...");
}

const prisma = new PrismaClient({
  log:
    process.env.NODE_ENV === "development"
      ? ["query", "error", "warn"]
      : ["error"],

});

const connectDB = async () => {
  try {
    await prisma.$connect();
    console.log("DB Connected via Prisma");
  } catch (error) {
    console.log("Database connection error:", error);
    process.exit(1);
  }
};

const disconnectDB = async () => {
  await prisma.$disconnect();
};

export { prisma, connectDB, disconnectDB };
