import {
  getApartmentsService,
  createApartmentService,
  updateApartmentService,
  deleteApartmentService,
} from "../services/apartmentService.js";

// GET /api/v1/buildings/:buildingId/apartments
export const getApartments = async (req, res, next) => {
  try {
    const { buildingId } = req.params;
    const managerId = req.user.id;

    const apartments = await getApartmentsService(buildingId, managerId);

    if (!apartments) {
      const error = new Error("Bu binanın dairelerini görüntüleme yetkiniz yok.");
      error.statusCode = 403;
      return next(error);
    }

    res.status(200).json({
      success: true,
      data: apartments,
    });
  } catch (error) {
    next(error);
  }
};

// POST /api/v1/buildings/:buildingId/apartments
export const createApartment = async (req, res, next) => {
  try {
    const { buildingId } = req.params;
    const { number, floor } = req.body;
    const managerId = req.user.id;

    if (!number) {
      const error = new Error("Daire numarası zorunludur.");
      error.statusCode = 400;
      return next(error);
    }

    const apartment = await createApartmentService({
      buildingId,
      number: number.trim(),
      floor: floor ? Number(floor) : null,
      managerId,
    });

    if (!apartment) {
      const error = new Error("Bu binaya daire ekleme yetkiniz yok.");
      error.statusCode = 403;
      return next(error);
    }

    res.status(201).json({
      success: true,
      message: "Daire başarıyla oluşturuldu.",
      data: apartment,
    });
  } catch (error) {
    next(error);
  }
};

// PUT /api/v1/buildings/:buildingId/apartments/:id
export const updateApartment = async (req, res, next) => {
  try {
    const { buildingId, id } = req.params;
    const { number, floor } = req.body;
    const managerId = req.user.id;

    if (!number) {
      const error = new Error("Daire numarası zorunludur.");
      error.statusCode = 400;
      return next(error);
    }

    const updated = await updateApartmentService(id, buildingId, managerId, {
      number: number.trim(),
      floor: floor ? Number(floor) : null,
    });

    if (!updated) {
      const error = new Error("Daire bulunamadı veya güncelleme yetkiniz yok.");
      error.statusCode = 404;
      return next(error);
    }

    res.status(200).json({
      success: true,
      message: "Daire güncellendi.",
      data: updated,
    });
  } catch (error) {
    next(error);
  }
};

// DELETE /api/v1/buildings/:buildingId/apartments/:id
export const deleteApartment = async (req, res, next) => {
  try {
    const { buildingId, id } = req.params;
    const managerId = req.user.id;

    const deleted = await deleteApartmentService(id, buildingId, managerId);

    if (!deleted) {
      const error = new Error("Daire bulunamadı veya silme yetkiniz yok.");
      error.statusCode = 404;
      return next(error);
    }

    res.status(200).json({
      success: true,
      message: "Daire silindi.",
    });
  } catch (error) {
    next(error);
  }
};