import { prisma } from "../config/db.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { generateAccessToken, generateRefreshToken } from "../utils/generateTokens.js";

const register = async (req, res, next) => {
  try {
    const { name, email, phone, password } = req.body;

    const mevcutKullanici = await prisma.user.findUnique({
      where: { email: email },
    });
    if (mevcutKullanici) {
      const error = new Error("Bu email adresi zaten kullanılıyor.");
      error.statusCode = 400;
      return next(error);
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await prisma.user.create({
      data: {
        name,
        email,
        phone,
        passwordHash: hashedPassword,
        role: "MANAGER", // Normal kayıt olanlar otomatik MANAGER
      },
    });

    const accessToken = generateAccessToken(user);
    const refreshToken = generateRefreshToken(user);

    res.status(201).json({
      success: true,
      message: "Hesabınız başarıyla oluşturuldu.",
      data: {
        accessToken,
        refreshToken,
        user: { id: user.id, email: user.email, name: user.name, role: user.role, phone: user.phone }
      }
    });
  } catch (error) {
    next(error);
  }
};

const login = async (req, res, next) => {
  try {
    const { email, phone, password } = req.body;
    const user = await prisma.user.findUnique({
      where: { email: email },
    });
    if (!user) {
      const error = new Error("Email veya şifre hatalı.");
      error.statusCode = 400;
      return next(error);
    }
    const isPasswordValid = await bcrypt.compare(password, user.passwordHash);
    if (!isPasswordValid) {
      const error = new Error("Email veya şifre hatalı.");
      error.statusCode = 400;
      return next(error);
    }
    const accessToken = generateAccessToken(user);
    const refreshToken = generateRefreshToken(user);
    res.status(200).json({
      success: true,
      message: "Giriş başarılı.",
      data: {
        accessToken,
        refreshToken,
        user: { id: user.id, email: user.email, name: user.name, role: user.role, phone: user.phone }
      }
    });
  } catch (error) {
    next(error);
  }
};

const refreshToken = async (req, res, next) => {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken) {
      const error = new Error("Refresh token gerekli.");
      error.statusCode = 401;
      return next(error);
    }
    const decoded = jwt.verify(refreshToken, process.env.REFRESH_TOKEN_SECRET);
    const user = await prisma.user.findUnique({ where: { id: decoded.id } });
    if (!user) {
      const error = new Error("Kullanıcı bulunamadı.");
      error.statusCode = 404;
      return next(error);
    }
    const newAccessToken = generateAccessToken(user);
    res.status(200).json({ 
      success: true,
      data: { accessToken: newAccessToken } 
    });
  } catch (error) {
    if (error.name === "JsonWebTokenError" || error.name === "TokenExpiredError") {
      const err = new Error("Geçersiz veya süresi dolmuş refresh token.");
      err.statusCode = 403;
      return next(err);
    }
    next(error);
  }
};

/* const join = async (req, res) => {
  const { name, email, phone, password, inviteCode } = req.body;

  // Davet kodunu kontrol et
  const code = await prisma.inviteCode.findUnique({
    where: { code: inviteCode },
    include: { apartment: true }
  });

  if (!code) {
    return res.status(400).json({ error: "Geçersiz davet kodu." });
  }

  if (code.usedAt) {
    return res.status(400).json({ error: "Bu davet kodu zaten kullanılmış." });
  }

  if (code.expiresAt < new Date()) {
    return res.status(400).json({ error: "Davet kodunun süresi dolmuş." });
  }

  // Email zaten kullanılıyor mu kontrol et
  const mevcutKullanici = await prisma.user.findUnique({
    where: { email: email },
  });
  if (mevcutKullanici) {
    return res.status(400).json({ error: "Bu email adresi zaten kullanılıyor." });
  }

  const haeshedPassword = await bcrypt.hash(password, 10);

  // RESIDENT olarak kullanıcı oluştur
  const user = await prisma.user.create({
    data: {
      name,
      email,
      phone,
      passwordHash: hashedPassword,
      role: "RESIDENT",
      apartmentId: code.apartmentId, // Davet kodunun bağlı olduğu daire
    },
  });

  // Davet kodunu kullanıldı olarak işaretle
  await prisma.inviteCode.update({
    where: { id: code.id },
    data: {
      usedAt: new Date(),
      usedBy: user.id,
    },
  });

  // Token'lar oluştur
  const accessToken = generateAccessToken(user);
  const refreshToken = generateRefreshToken(user);

  res.status(201).json({
    message: "Apartmana başarıyla katıldınız.",
    accessToken,
    refreshToken,
    user: { 
      id: user.id, 
      email: user.email, 
      name: user.name, 
      role: user.role,
      apartmentId: user.apartmentId
    },
  });
}; */

const logout = async (req, res, next) => {
  try {
    // Client-side token silme islemi
    // Not: Stateless JWT'da server tarafinda token invalidation icin
    // blacklist/whitelist sistemi gerekir (Redis vb.)
    res.status(200).json({ 
      success: true,
      message: "Çıkış başarılı." 
    });
  } catch (error) {
    next(error);
  }
};

export { register, login, refreshToken, logout};