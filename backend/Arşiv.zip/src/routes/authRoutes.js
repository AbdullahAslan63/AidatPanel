import express from "express";
import { register, login, refreshToken, logout} from "../controllers/authControllers.js";
import { authLimiter } from "../middlewares/rateLimitMiddleware.js";
import { validate, authSchemas } from "../middlewares/validate.js";
import { authMiddleware } from "../middlewares/authMiddleware.js";

const router = express.Router();

// Auth endpoint'leri
// Rate limiting - Brute force koruması (sadece login/register için)
router.post("/register", authLimiter, validate(authSchemas.register), register);
router.post("/login", authLimiter, validate(authSchemas.login), login);
router.post("/refresh", validate(authSchemas.refreshToken), refreshToken);
// router.post("/join", authLimiter, validate(authSchemas.join), join);
router.post("/logout", authMiddleware, logout);

export default router;
