import { prisma } from "../config/db.js";

export const createBuildingService = async ({ name, address, city, managerId }) => {
  return await prisma.building.create({
    data: { name, address, city, managerId },
  });
};

export const getBuildingsService = async (managerId) => {
  return await prisma.building.findMany({
    where: { managerId },
    orderBy: { createdAt: "desc" },
    include: {
      apartments: {
        include: {
          residents: {
            select: {
              id: true,
              name: true,
              email: true,
              phone: true,
            }
          },
          dues: {
            select: {
              id: true,
              amount: true,
              month: true,
              year: true,
              status: true,
              paidAt: true,
            }
          },
          inviteCodes: {
            select: {
              id: true,
              code: true,
              usedAt: true,
              expiresAt: true,
            }
          }
        }
      },
      expenses: {
        select: {
          id: true,
          title: true,
          amount: true,
          category: true,
          date: true,
        }
      }
    }
  });
};

export const getBuildingByIdService = async (id, managerId) => {
  return await prisma.building.findFirst({
    where: { id, managerId },
    include: {
      apartments: {
        include: {
          residents: {
            select: {
              id: true,
              name: true,
              email: true,
              phone: true,
            }
          },
          dues: {
            select: {
              id: true,
              amount: true,
              month: true,
              year: true,
              status: true,
              paidAt: true,
            }
          },
          inviteCodes: {
            select: {
              id: true,
              code: true,
              usedAt: true,
              expiresAt: true,
            }
          },
          tickets: {
            include: {
              updates: true
            }
          }
        }
      },
      expenses: {
        select: {
          id: true,
          title: true,
          amount: true,
          category: true,
          date: true,
        }
      }
    }
  });
};

export const updateBuildingService = async (id, managerId, data) => {
  const building = await prisma.building.findFirst({
    where: { id, managerId },
  });

  if (!building) return null;

  return await prisma.building.update({
    where: { id },
    data,
  });
};

export const deleteBuildingService = async (id, managerId) => {
  const building = await prisma.building.findFirst({
    where: { id, managerId },
    include: {
      apartments: {
        include: {
          dues: true,
          inviteCodes: true,
          tickets: {
            include: {
              updates: true
            }
          }
        }
      },
      expenses: true
    }
  });

  if (!building) return null;

  // Cascade delete with transaction
  return await prisma.$transaction(async (tx) => {
    // 1. Delete all ticket updates and tickets for each apartment
    for (const apartment of building.apartments) {
      for (const ticket of apartment.tickets) {
        await tx.ticketUpdate.deleteMany({
          where: { ticketId: ticket.id }
        });
      }
      await tx.ticket.deleteMany({
        where: { apartmentId: apartment.id }
      });
    }

    // 2. Delete all dues for each apartment
    for (const apartment of building.apartments) {
      await tx.due.deleteMany({
        where: { apartmentId: apartment.id }
      });
    }

    // 3. Delete all invite codes for each apartment
    for (const apartment of building.apartments) {
      await tx.inviteCode.deleteMany({
        where: { apartmentId: apartment.id }
      });
    }

    // 4. Delete all apartments
    await tx.apartment.deleteMany({
      where: { buildingId: id }
    });

    // 5. Delete all expenses
    await tx.expense.deleteMany({
      where: { buildingId: id }
    });

    // 6. Finally delete the building
    return await tx.building.delete({
      where: { id }
    });
  });
};